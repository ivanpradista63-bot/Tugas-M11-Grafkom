# LAPORAN PRAKTIKUM GRAFIKA KOMPUTER
## MINGGU KE-11: 3D VISUAL REALISM SUITE
### IMPLEMENTASI SHADING MODELS, FLAT VS SMOOTH SHADING, HIDDEN SURFACE REMOVAL, TEXTURE MAPPING, DAN REAL-TIME SHADOW MAPPING BERBASIS JAVA OOP & GLSL

---

**Disusun Oleh:**
* **Nama Lengkap:** Ivan Okta Arya Pradista
* **Nomor Induk Mahasiswa (NIM):** 25050974023
* **Kelas:** 2025A
* **Program Studi:** S1 Pendidikan Teknologi Informasi
* **Jurusan / Departemen:** Teknik Informatika
* **Fakultas:** Fakultas Teknik
* **Perguruan Tinggi:** Universitas Negeri Surabaya (UNESA)
* **Mata Kuliah:** Grafika Komputer (CGO-301) — 2 SKS (1 Teori, 1 Praktikum)
* **Dosen Pengampu:** Drs. Bambang Sujatmiko, M.T.
* **Tautan Repository GitHub:** [https://github.com/ivanokta/Grafika-Komputer-3D-Visual-Realism-Suite](https://github.com/ivanokta/Grafika-Komputer-3D-Visual-Realism-Suite)

---

## DAFTAR ISI

1. [BAGIAN 1: COVER & IDENTITAS](#bagian-1-cover--identitas)
2. [BAGIAN 2: DASAR TEORI & FORMULASI MATEMATIKA](#bagian-2-dasar-teori--formulasi-matematika)
   - 2.1 Model Pencahayaan Lokal: Phong vs Blinn-Phong Reflection Model
   - 2.2 Interpolasi Permukaan: Flat Shading vs Smooth Shading & Mach Band Effect
   - 2.3 Hidden Surface Removal: Z-Buffer Depth Test & Back-Face Culling
   - 2.4 Pemetaan Tekstur (Texture Mapping): UV Parameterization & Filtering (Nearest vs Mipmap)
   - 2.5 Real-Time Shadow Mapping 2-Pass: Depth Framebuffer, Shadow Bias, dan PCF
3. [BAGIAN 3: STRUKTUR KODE & IMPLEMENTASI ARSITEKTUR](#bagian-3-struktur-kode--implementasi-arsitektur)
   - 3.1 Diagram Arsitektur Proyek dan Alur Data GPU
   - 3.2 Penjelasan Kelas Komponen Java OOP
   - 3.3 Penjelasan Shader GLSL 330 Core
   - 3.4 Mekanisme Render Loop Dua Pass (Two-Pass Rendering Pipeline)
4. [BAGIAN 4: TANGKAPAN LAYAR & HASIL PENGUJIAN](#bagian-4-tangkapan-layar--hasil-pengujian)
   - 4.1 Pengujian Indikator 1: Shading Model Phong vs Blinn-Phong
   - 4.2 Pengujian Indikator 2: Flat Shading vs Smooth Shading
   - 4.3 Pengujian Indikator 3: Hidden Surface Removal (Z-Buffer & Culling ON/OFF)
   - 4.4 Pengujian Indikator 4: Texture Mapping & Filtering (Nearest vs Mipmapped)
   - 4.5 Pengujian Indikator 5: Real-Time Shadow Mapping, Shadow Acne, dan Peter Panning
5. [BAGIAN 5: PEMBAHASAN & KESIMPULAN](#bagian-5-pembahasan--kesimpulan)
   - 5.1 Analisis Komparasi Kinerja Rendering (Tabel Data Benchmark FPS)
   - 5.2 Analisis Fenomena Shadow Bias: Komparasi Shadow Acne dan Peter Panning
   - 5.3 Analisis Perbedaan Mendasar Gouraud Shading vs Phong Shading
   - 5.4 Kesimpulan Kontribusi Pilar Visual Realism

---

## BAGIAN 1: COVER & IDENTITAS

* **Mata Kuliah:** Grafika Komputer (CGO-301)
* **Semester / SKS:** Semester V / 2 SKS
* **Dosen Pengampu:** Drs. Bambang Sujatmiko, M.T.
* **Nama Penyusun:** Ivan Okta Arya Pradista
* **NIM:** 25050974023
* **Kelas:** 2025A
* **Link Repository GitHub:** [https://github.com/ivanokta/Grafika-Komputer-3D-Visual-Realism-Suite](https://github.com/ivanokta/Grafika-Komputer-3D-Visual-Realism-Suite)

---

## BAGIAN 2: DASAR TEORI & FORMULASI MATEMATIKA

Visual Realism dalam bidang Grafika Komputer 3D adalah cabang ilmu yang mempelajari pendekatan komputasional untuk mensimulasikan hukum-hukum optika fisik (*physical optics*) pada permukaan geometri 3D (*rendering faces*). Lima pilar yang diimplementasikan pada praktikum ini memiliki dasar teori dan formulasi matematis sebagai berikut:

### 2.1 Model Pencahayaan Lokal: Phong vs Blinn-Phong Reflection Model

Model pencahayaan lokal menghitung interaksi cahaya yang dipantulkan dari titik permukaan $\mathbf{P}$ menuju posisi pengamat $\mathbf{V}$.

#### a. Model Pantulan Phong (Bui Tuong Phong, 1975)
Model Phong membagi intensitas cahaya pantulan total ($I_{total}$) menjadi tiga komponen aditif:
$$I_{total} = I_{ambient} + I_{diffuse} + I_{specular}$$

Secara formulasi matematis lengkap:
$$I_{total} = (k_a \cdot I_a) + \Big(k_d \cdot I_d \cdot \max(\mathbf{N} \cdot \mathbf{L}, 0)\Big) + \Big(k_s \cdot I_s \cdot \max(\mathbf{R} \cdot \mathbf{V}, 0)^n\Big)$$

Dimana:
* $\mathbf{N}$: Vektor normal permukaan pada titik fragmen (ternormalisasi, $\|\mathbf{N}\| = 1$).
* $\mathbf{L}$: Vektor arah dari titik fragmen menuju sumber cahaya ($\mathbf{L} = \frac{\mathbf{P}_{light} - \mathbf{P}_{frag}}{\|\mathbf{P}_{light} - \mathbf{P}_{frag}\|}$).
* $\mathbf{V}$: Vektor arah pandang dari titik fragmen menuju kamera ($\mathbf{V} = \frac{\mathbf{P}_{cam} - \mathbf{P}_{frag}}{\|\mathbf{P}_{cam} - \mathbf{P}_{frag}\|}$).
* $\mathbf{R}$: Vektor pantulan cermin sempurna dari arah datang cahaya terhadap normal permukaan, dirumuskan melalui hukum pemantulan optis:
  $$\mathbf{R} = 2(\mathbf{N} \cdot \mathbf{L})\mathbf{N} - \mathbf{L}$$
* $k_a, k_d, k_s$: Koefisien pantulan material untuk ambient, diffuse, dan specular.
* $I_a, I_d, I_s$: Intensitas energi cahaya ambient, diffuse, dan specular.
* $n$: Eksponen kilap (*shininess factor*). Nilai $n$ yang semakin besar menghasilkan specular highlight yang semakin sempit, tajam, dan memusat (menyerupai permukaan logam atau cermin kaca).

#### b. Model Pantulan Blinn-Phong (Jim Blinn, 1977)
Kelemahan matematis model Phong standar terletak pada kebutuhan mengevaluasi vektor pantulan $\mathbf{R}$ yang melibatkan operasi perkalian dot dan pengurangan vektor per-pixel. Selain itu, ketika sudut antara $\mathbf{R}$ dan $\mathbf{V}$ melebihi $90^\circ$, kilauan specular langsung terputus secara diskontinu.

Jim Blinn memodifikasi model ini dengan memperkenalkan **Halfway Vector** ($\mathbf{H}$), yaitu vektor satuan yang berada tepat di tengah-tengah antara arah sumber cahaya $\mathbf{L}$ dan arah pengamat $\mathbf{V}$:
$$\mathbf{H} = \frac{\mathbf{L} + \mathbf{V}}{\|\mathbf{L} + \mathbf{V}\|}$$

Komponen specular Blinn-Phong dievaluasi melalui perkalian dot antara normal permukaan $\mathbf{N}$ dengan vektor $\mathbf{H}$:
$$I_{specular\_blinn} = k_s \cdot I_s \cdot \max(\mathbf{N} \cdot \mathbf{H}, 0)^{n_{blinn}}$$

**Hubungan Eksponen Shininess:**
Karena sudut antara $\mathbf{N}$ dan $\mathbf{H}$ kira-kira bernilai setengah dari sudut antara $\mathbf{R}$ dan $\mathbf{V}$ ($\angle(\mathbf{N}, \mathbf{H}) \approx \frac{1}{2} \angle(\mathbf{R}, \mathbf{V})$), maka untuk menghasilkan ukuran specular highlight yang secara visual setara, nilai eksponen kilap Blinn-Phong ($n_{blinn}$) harus disetel sekitar 2 hingga 4 kali lebih besar daripada eksponen Phong ($n_{phong}$). Pada modul praktikum ini, digunakan $n_{phong} = 16$ dan $n_{blinn} = 32$.

---

### 2.2 Interpolasi Permukaan: Flat Shading vs Smooth Shading & Mach Band Effect

Taraf visual permukaan 3D sangat ditentukan oleh bagaimana vektor normal dihitung dan diinterpolasikan melintasi primitif poligon segitiga.

#### a. Flat Shading (Facet Shading)
Pada Flat Shading, satu vektor normal tunggal dihitung untuk seluruh bidang datar segitiga (*face normal*). Untuk segitiga yang dibentuk oleh tiga verteks $\mathbf{p}_0, \mathbf{p}_1, \mathbf{p}_2$ dengan urutan counter-clockwise (CCW):
$$\mathbf{N}_{face} = \frac{(\mathbf{p}_1 - \mathbf{p}_0) \times (\mathbf{p}_2 - \mathbf{p}_0)}{\|(\mathbf{p}_1 - \mathbf{p}_0) \times (\mathbf{p}_2 - \mathbf{p}_0)\|}$$

Seluruh fragmen di dalam batas segitiga menerima vektor normal $\mathbf{N}_{face}$ yang konstan. Akibatnya, permukaan objek kurva (seperti bola) tampak berpetak-petak (*polyhedral/faceted*). Fenomena persepsi manusia yang dikenal sebagai **Mach Band Effect** menyebabkan sistem visual mata manusia memperkuat kontras intensitas pada garis batas pertemuan dua poligon yang bertetangga, sehingga garis rusuk segitiga terlihat lebih kontras dan tajam dari intensitas warna aslinya.

#### b. Smooth Shading (Vertex Normal Averaging)
Smooth Shading menghilangkan batas diskontinuitas visual antar facet dengan menetapkan vektor normal pada masing-masing titik sudut (*vertex normal*). Vektor normal vertex dihitung melalui perataan (*averaging*) seluruh normal bidang muka segitiga yang berbagi (*share*) titik verteks tersebut:
$$\mathbf{N}_{vertex} = \frac{\sum_{i=1}^{m} \mathbf{N}_{face\_i}}{\|\sum_{i=1}^{m} \mathbf{N}_{face\_i}\|}$$

Pada model bola (Sphere) yang berpusat di titik origin $(0,0,0)$ dengan jari-jari $r$, vektor normal analitik pada setiap verteks $\mathbf{p} = (x, y, z)$ tepat sama dengan posisi verteks yang dinormalisasi:
$$\mathbf{N}_{vertex} = \frac{\mathbf{p}}{\|\mathbf{p}\|} = \left(\frac{x}{r}, \frac{y}{r}, \frac{z}{r}\right)$$

Pada tahap rasterisasi, normal verteks ini diinterpolasikan secara perspektif-korektif (*perspective-correct barycentric interpolation*) ke seluruh fragmen pixel pada fragment shader (Phong Shading / Per-Pixel Lighting), menghasilkan gradasi shading yang lembut dan kontinyu tanpa cacat Mach Banding.

---

### 2.3 Hidden Surface Removal: Z-Buffer Depth Test & Back-Face Culling

Untuk mencegah poligon yang berada di bagian belakang tergambar menutupi poligon yang berada di depan kamera, diterapkan algoritma Hidden Surface Removal (HSR).

#### a. Algoritma Z-Buffer (Catmull, 1974)
Z-Buffer mengalokasikan array memori dua dimensi berukuran $W \times H$ yang menyimpan nilai kedalaman $Z \in [0.0, 1.0]$ untuk setiap pixel layar. Pada awal frame, Z-Buffer direset ke nilai maksimum ($1.0$). Saat suatu fragmen pada posisi $(x, y)$ dengan kedalaman $z_{frag}$ diproses:
* Jika $z_{frag} < \text{ZBuffer}[x, y]$, maka fragmen tersebut lebih dekat ke kamera. Fragmen lolos uji kedalaman (*depth test pass*), warna pixel ditulis ke Color Buffer, dan nilai kedalaman diperbarui: $\text{ZBuffer}[x, y] \leftarrow z_{frag}$.
* Jika $z_{frag} \ge \text{ZBuffer}[x, y]$, maka fragmen tersebut terhalang oleh geometri lain yang lebih dekat. Fragmen dibuang (*depth test fail* / discarded).

**Z-Fighting:** Terjadi apabila dua permukaan saling berhimpit atau memiliki jarak $z$ yang terlampau kecil dibanding batas presisi floating-point Z-Buffer. Pemetaan kedalaman non-linier OpenGL dihitung melalui:
$$z_{window} = \frac{z_{far} + z_{near}}{z_{far} - z_{near}} + \frac{1}{z_{view}} \cdot \frac{2 \cdot z_{far} \cdot z_{near}}{z_{near} - z_{far}}$$
Presisi Z-Buffer sangat rapat di dekat $z_{near}$ dan sangat renggang mendekati $z_{far}$. Untuk mencegah Z-fighting, rasio $\frac{z_{far}}{z_{near}}$ harus dijaga proporsional (pada praktikum ini dipilih $z_{near} = 0.1$ dan $z_{far} = 100.0$, rasio 1000:1).

#### b. Back-Face Culling
Back-Face Culling mengeliminasi poligon-poligon yang menghadap membelakangi kamera sebelum poligon tersebut memasuki tahap fragment shader. Arah hadap ditentukan oleh perkalian dot antara normal segitiga $\mathbf{N}$ dan vektor pandang pengamat $\mathbf{V}$:
$$\mathbf{N} \cdot \mathbf{V} \ge 0 \implies \text{Back-Face (Dibuang / Culled)}$$

Dalam pipeline OpenGL modern, penentuan arah muka poligon dilakukan melalui urutan putaran verteks (*winding order*). Segitiga yang verteks-verteksnya terproyeksikan secara berlawanan arah jarum jam (Counter-Clockwise / CCW) didefinisikan sebagai *Front-Facing*, sedangkan yang searah jarum jam (Clockwise / CW) dianggap *Back-Facing* dan langsung dieliminasi melalui instruksi `glCullFace(GL_BACK)`.

---

### 2.4 Pemetaan Tekstur (Texture Mapping): UV Parameterization & Filtering

Texture Mapping memetakan gambar bitmap 2D ke atas permukaan mesh 3D menggunakan ruang parameter koordinat UV $(u, v) \in [0.0, 1.0]^2$.

#### a. Koordinat Tekstur pada Geometri Bola
Untuk bola dengan parameter sudut polar $\phi \in [0, \pi]$ (dari kutub utara ke selatan) dan sudut azimut $\theta \in [0, 2\pi]$:
$$u = \frac{\theta}{2\pi} = \frac{j}{\text{sectors}}, \quad v = 1 - \frac{\phi}{\pi} = 1 - \frac{i}{\text{stacks}}$$

#### b. Texture Filtering & Mipmapping
Ketika proyeksi luasan suatu pixel di layar tidak berbanding 1:1 dengan satu texel pada citra tekstur, terjadi fenomena aliasing.
1. **Nearest Neighbor Filtering (`GL_NEAREST`):** Mengambil warna satu texel yang koordinatnya paling dekat dengan koordinat UV fragmen. Saat dilihat dari sudut miring atau jarak jauh, terjadi artifak pikselasi kasar dan pola interferensi bergelombang (*Moiré pattern*).
2. **Bilinear + Mipmapping Filtering (`GL_LINEAR_MIPMAP_LINEAR`):** Mipmapping membuat piramida citra tekstur beresolusi bertingkat ($D_0 = 512\times 512, D_1 = 256\times 256, \dots, D_9 = 1\times 1$). Trilinear filtering melakukan interpolasi bilinear pada dua level mipmap yang paling sesuai dengan rasio texel-to-pixel, kemudian menginterpolasi linier hasil keduanya. Pendekatan ini sepenuhnya menghilangkan aliasing dan efek Moiré.

---

### 2.5 Real-Time Shadow Mapping 2-Pass: Depth Framebuffer, Shadow Bias, dan PCF

Shadow Mapping (Lance Williams, 1978) adalah teknik penentuan bayangan real-time yang membagi proses render menjadi dua tahap (*two-pass algorithm*).

#### a. Pass 1: Depth Map Generation
Kamera virtual diletakkan pada posisi sumber cahaya directional $\mathbf{P}_{light}$. Scene dirender hanya untuk merekam jarak kedalaman objek dari sudut pandang cahaya ke dalam tekstur depth buffer 2D (Depth Attachment FBO berukuran $2048 \times 2048$). Matriks transformasi ruang cahaya dihitung melalui perkalian proyeksi ortografis dan matriks view cahaya:
$$\mathbf{M}_{lightSpace} = \mathbf{P}_{light} \cdot \mathbf{V}_{light}$$

#### b. Pass 2: Scene Rendering & Shadow Test
Scene dirender dari sudut pandang kamera pengamat utama. Setiap fragmen yang diproses pada fragment shader ditransformasikan ke dalam sistem koordinat ruang cahaya (*light space*):
$$\mathbf{p}_{lightSpace} = \mathbf{M}_{lightSpace} \cdot \mathbf{M}_{model} \cdot \mathbf{p}_{local}$$

Melalui pembagian perspektif (*perspective division*) dan pemetaan dari NDC $[-1, 1]$ ke rentang tekstur $[0, 1]$:
$$\mathbf{p}_{proj} = \frac{\mathbf{p}_{lightSpace}.xyz}{\mathbf{p}_{lightSpace}.w} \times 0.5 + 0.5$$

Kedalaman fragmen saat ini terhadap cahaya adalah $\mathbf{p}_{proj}.z$, sedangkan kedalaman titik terdekat yang terlihat oleh cahaya adalah $d_{closest} = \text{texture}(\text{shadowMap}, \mathbf{p}_{proj}.xy).r$.
Uji bayangan:
$$\mathbf{p}_{proj}.z - \text{bias} > d_{closest} \implies \text{Objek Berada Dalam Bayangan (Shadowed)}$$

#### c. Mitigasi Shadow Acne vs Peter Panning (Shadow Bias)
* **Shadow Acne:** Disebabkan oleh keterbatasan resolusi diskret depth map. Beberapa fragmen pada permukaan yang menghadap cahaya keliru dianggap lebih dalam daripada texel depth map tetangganya, memunculkan garis-garis hitam belang-belang (*self-shadowing artifact*). Fenomena ini terjadi jika $\text{bias} = 0$.
* **Peter Panning:** Jika bias yang ditambahkan terlalu besar secara konstan, permukaan objek terdorong terlalu jauh dari kedalaman aslinya, menyebabkan bayangan terlepas (*detached*) melayang dari dasar objek.
* **Solusi Dynamic Slope-Scale Bias:** Besar bias disesuaikan secara dinamis terhadap sudut kemiringan permukaan terhadap arah datangnya cahaya:
  $$\text{bias} = \max\Big(0.05 \cdot (1.0 - \mathbf{N} \cdot \mathbf{L}), \, 0.005\Big)$$

#### d. Percentage-Closer Filtering (PCF) 3×3
Untuk menghindari tepi bayangan yang bergerigi kasar (*staircasing artifact*), dilakukan pengambilan sampel 9 texel bertetangga ($3 \times 3$ grid) di sekitar koordinat proyeksi, lalu merata-ratakan faktor penerangan:
$$S_{lit} = \frac{1}{9} \sum_{x=-1}^{1} \sum_{y=-1}^{1} \Big(\mathbf{p}_{proj}.z - \text{bias} \le \text{texture}(\text{shadowMap}, \mathbf{p}_{proj}.xy + (x, y) \cdot \Delta_{texel})\Big)$$
Hasilnya menghasilkan bayangan bertepi halus (*soft shadow penumbra*).

---

## BAGIAN 3: STRUKTUR KODE & IMPLEMENTASI ARSITEKTUR

### 3.1 Diagram Arsitektur Proyek dan Alur Data GPU

Aplikasi dirancang menggunakan arsitektur Object-Oriented Programming (OOP) terstruktur di dalam package `com.grafkom.viewing3d`:

```
com.grafkom.viewing3d
 ├── Main.java              <- Orchestrator window GLFW, render loop 2-pass, FPS counter
 ├── AutoTestRunner.java    <- Runner otomasi pengujian seluruh skenario & capture screenshot
 ├── InputState.java        <- Enkapsulasi status interaksi keyboard (B, F, Z, C, T, N, H, P, K)
 ├── Mesh.java              <- Enkapsulasi VAO/VBO/EBO, sphere builder (smooth & flat), ground plane
 ├── HSRManager.java        <- Pengendali state OpenGL untuk Z-Buffer dan Back-Face Culling
 ├── Texture2D.java         <- Pemuat citra tekstur (STBImage), GPU binding, filter switcher
 ├── ShadowMapFBO.java      <- Framebuffer Object untuk perekaman 2048x2048 Depth Map
 ├── ShaderProgram.java     <- Pengelola kompilasi, linking shader GLSL, dan uniform setters
 ├── Camera3D.java          <- Sistem kamera sintetis orbital (u, v, n) & LookAt Matrix
 └── PerspectiveProjection.java <- Frustum perspektif simetris & pembaruan aspek rasio adaptif
```

### 3.2 Penjelasan Kelas Komponen Java OOP

1. **`Mesh.java`:** Mengelola siklus hidup memori GPU untuk Vertex Array Object (VAO), Vertex Buffer Object (VBO), dan Element Buffer Object (EBO). Format data vertex mengadopsi struktur terpadu 8-float beruntun:
   `[Position.xyz (3 float) | Normal.xyz (3 float) | TexCoords.uv (2 float)]` dengan total stride sebesar $8 \times 4 = 32$ byte. Kelas ini menyediakan *factory method* untuk membentuk geometri bola beresolusi 16 stacks × 24 sectors dalam varian *Smooth* (indexed sharing vertex) dan *Flat* (non-indexed duplikasi 3 verteks per-segitiga dengan normal bidang muka identik), serta bidang lantai (Ground Plane).
2. **`HSRManager.java`:** Kelas statik modular yang mengabstraksi pemanggilan state OpenGL untuk Hidden Surface Removal. Metode `setupDepthTest(boolean enable)` mengaktifkan `GL_DEPTH_TEST` dengan fungsi `GL_LESS`. Metode `setupBackFaceCulling(boolean enable)` mengaktifkan `GL_CULL_FACE` dengan target `GL_BACK` dan konvensi *front face* `GL_CCW`.
3. **`Texture2D.java`:** Mengintegrasikan pustaka `org.lwjgl.stb.STBImage` untuk membaca file gambar PNG/JPG dari disk ke ByteBuffer memori GPU secara aman menggunakan `MemoryStack`. Dilengkapi fungsi `setFilter(boolean mipmapped)` yang dapat mengubah filter tekstur secara real-time dari `GL_NEAREST` ke `GL_LINEAR_MIPMAP_LINEAR`.
4. **`ShadowMapFBO.java`:** Mengenkapsulasi pembuatan Framebuffer Object mandiri khusus kedalaman (*depth-only FBO*). Mengalokasikan tekstur kedalaman beresolusi tinggi $2048 \times 2048$ bertipe `GL_DEPTH_COMPONENT` dengan parameter wrap `GL_CLAMP_TO_BORDER` (warna border putih $1.0$).
5. **`ShaderProgram.java`:** Mengabstraksi operasi kompilasi GLSL vertex shader dan fragment shader, verifikasi status error link melalui `glGetProgramInfoLog`, serta menyediakan fungsi transfer uniform matriks 4×4 (`setMat4`), vektor 3D (`setVec3`), skalar, dan boolean ke register GPU.
6. **`InputState.java`:** Mengelola variabel boolean flags seluruh fitur interaktif dan menangani pemetaan tombol keyboard GLFW (`GLFW_PRESS`) secara independen untuk mencegah *key-bounce*.

### 3.3 Penjelasan Shader GLSL 330 Core

* **`phong.vert`:** Mentransformasikan koordinat posisi lokal ke koordinat dunia (`FragPos`), menghitung normal matriks $\text{transpose}(\text{inverse}(\mathbf{M}_{model}))$ untuk memastikan vektor normal tetap ortogonal terhadap permukaan meskipun objek mengalami penskalaan non-uniform, meneruskan koordinat UV tekstur, serta menghitung posisi fragmen dalam ruang cahaya `FragPosLightSpace = lightSpaceMatrix * vec4(FragPos, 1.0)`.
* **`phong.frag`:** Mengevaluasi pencahayaan per-pixel dengan dukungan switch uniform `useBlinnPhong`, `useTexture`, `useShadow`, `shadowBiasMode`, dan `usePCF`. Menghitung komponen ambient ($0.2 \cdot I_{light}$), komponen diffuse Lambertian ($\max(\mathbf{N} \cdot \mathbf{L}, 0) \cdot I_{light}$), komponen specular (Phong eksponen 16 vs Blinn-Phong eksponen 32), serta faktor peredaman bayangan real-time melalui fungsi `calculateShadow`.
* **`depth.vert` & `depth.frag`:** Shader khusus Pass 1 yang sangat ringan. Vertex shader hanya melakukan transformasi posisi puncak ke ruang cahaya `gl_Position = lightSpaceMatrix * model * vec4(aPos, 1.0)`. Fragment shader dikosongkan karena nilai kedalaman fragmen ditulis secara otomatis oleh perangkat keras GPU ke depth attachment.

### 3.4 Mekanisme Render Loop Dua Pass (Two-Pass Rendering Pipeline)

Setiap putaran frame pada `Main.java` mengeksekusi alur dua tahap:
1. **PASS 1 (Depth Shadow Map Generation):**
   * FBO shadow diikat melalui `shadowFBO.bindForWriting()`. Viewport disetel ke $2048 \times 2048$.
   * Buffer kedalaman FBO dibersihkan (`glClear(GL_DEPTH_BUFFER_BIT)`).
   * Depth test dipaksa selalu aktif (`glEnable(GL_DEPTH_TEST)`).
   * Culling disetel ke `GL_FRONT` guna mereduksi artefak bayangan pada permukaan depan bola.
   * `depthShader` diaktifkan dengan matriks ruang cahaya ortografis $\mathbf{M}_{lightSpace}$. Objek bola dirender ke dalam depth texture.
   * FBO dilepas melalui `shadowFBO.unbind(windowWidth, windowHeight)`.
2. **PASS 2 (Normal Camera Scene Rendering):**
   * Framebuffer utama layar dibersihkan (`glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)`).
   * Konfigurasi HSR diterapkan melalui `HSRManager` sesuai status flag interaktif (Z dan C).
   * `phongShader` diaktifkan, menerima matriks view kamera dan proyeksi perspektif.
   * Tekstur difus diikat ke Texture Unit 0, dan Depth Texture Shadow Map diikat ke Texture Unit 1.
   * Objek bola digambar terlebih dahulu dengan material warna/tekstur aktif.
   * Objek lantai (Ground Plane) digambar setelah objek bola untuk mendemonstrasikan secara visual kegagalan urutan overlap saat Z-Buffer dinonaktifkan.

---

## BAGIAN 4: TANGKAPAN LAYAR & HASIL PENGUJIAN

Seluruh hasil pengujian berikut diperoleh secara langsung dari eksekusi aplikasi pada GPU sistem lokal dengan menyertakan title bar HUD aktif:

### 4.1 Pengujian Indikator 1: Shading Model Phong vs Blinn-Phong

| (a) Model Pantulan Phong (Key 'B') | (b) Model Pantulan Blinn-Phong (Key 'B') |
|:---:|:---:|
| ![Phong](file:///c:/Users/Lenovo%20LOQ/Downloads/M11_023/Grafikom%20M10/screenshots/1a_Phong.png) | ![Blinn-Phong](file:///c:/Users/Lenovo%20LOQ/Downloads/M11_023/Grafikom%20M10/screenshots/1b_BlinnPhong.png) |
| *Gambar 4.1a: Phong Shading (Eksponen n = 16, FPS: 4.825,4).* | *Gambar 4.1b: Blinn-Phong Shading (Eksponen n = 32, FPS: 19.044,0).* |

* **Analisis Visual:** Pada model Phong standar (Gambar 4.1a), kilauan specular highlight memiliki batas lingkaran kilap yang sedikit lebih tegas dan evaluasi vektor refleksi $\mathbf{R}$ rentan terpotong saat sudut pandang mendekati tangensial. Pada Blinn-Phong (Gambar 4.1b), penggunaan Halfway Vector $\mathbf{H}$ menghasilkan kilauan specular yang lebih halus, transisi transparan eliptis yang lebih natural pada sudut pandang miring, serta kinerja komputasi GPU yang jauh lebih tinggi (19.044 FPS berbanding 4.825 FPS).

---

### 4.2 Pengujian Indikator 2: Flat Shading vs Smooth Shading

| (a) Flat Shading (Key 'F') | (b) Smooth Shading (Key 'F') |
|:---:|:---:|
| ![Flat](file:///c:/Users/Lenovo%20LOQ/Downloads/M11_023/Grafikom%20M10/screenshots/2a_FlatShading.png) | ![Smooth](file:///c:/Users/Lenovo%20LOQ/Downloads/M11_023/Grafikom%20M10/screenshots/2b_SmoothShading.png) |
| *Gambar 4.2a: Flat Shading dengan face normal terpisah (FPS: 16.982,7).* | *Gambar 4.2b: Smooth Shading dengan vertex normal averaging (FPS: 18.279,3).* |

* **Analisis Visual:** Pada Flat Shading (Gambar 4.2a), setiap facet segitiga memiliki warna seragam homogen dan batas rusuk antar poligon terlihat kontras akibat fenomena psikofisik Mach Banding. Pada Smooth Shading (Gambar 4.2b), interpolasi normal vertex di fragment shader menghasilkan permukaan bola yang bundar licin dan mulus sempurna tanpa batas diskontinuitas visual poligon.

---

### 4.3 Pengujian Indikator 3: Hidden Surface Removal (Z-Buffer & Culling)

| (a) Z-Buffer Depth Test ON (Key 'Z') | (b) Z-Buffer Depth Test OFF (Key 'Z') |
|:---:|:---:|
| ![Z-ON](file:///c:/Users/Lenovo%20LOQ/Downloads/M11_023/Grafikom%20M10/screenshots/3a_DepthTest_ON.png) | ![Z-OFF](file:///c:/Users/Lenovo%20LOQ/Downloads/M11_023/Grafikom%20M10/screenshots/3b_DepthTest_OFF.png) |
| *Gambar 4.3a: Z-Buffer ON, oklusi kedalaman objek tertata sempurna.* | *Gambar 4.3b: Z-Buffer OFF, lantai yang digambar terakhir menimpa bola.* |

| (c) Back-Face Culling ON (Key 'C') | (d) Back-Face Culling OFF (Key 'C') |
|:---:|:---:|
| ![Cull-ON](file:///c:/Users/Lenovo%20LOQ/Downloads/M11_023/Grafikom%20M10/screenshots/3c_CullFace_ON.png) | ![Cull-OFF](file:///c:/Users/Lenovo%20LOQ/Downloads/M11_023/Grafikom%20M10/screenshots/3d_CullFace_OFF.png) |
| *Gambar 4.3c: Culling ON, segitiga belakang dibuang (FPS: 26.384,1).* | *Gambar 4.3d: Culling OFF, semua segitiga diproses GPU (FPS: 18.867,3).* |

* **Analisis Visual:** Saat Z-Buffer dimatikan (Gambar 4.3b), terjadi kegagalan eliminasi permukaan tersembunyi yang fatal: bidang lantai (ground plane) yang digambar belakangan dalam kode program menimpa permukaan bola secara tidak logis (*painter's algorithm overlap failure*). Saat Back-Face Culling diaktifkan (Gambar 4.3c), performa GPU melonjak drastis hingga **26.384,1 FPS** karena setengah dari primitif segitiga dieliminasi pada tahap rasterisasi awal sebelum fragment shader dijalankan.

---

### 4.4 Pengujian Indikator 4: Texture Mapping & Filtering (Nearest vs Mipmap)

| (a) Nearest Neighbor Filtering (Key 'N') | (b) Bilinear + Mipmapping Filtering (Key 'N') |
|:---:|:---:|
| ![Nearest](file:///c:/Users/Lenovo%20LOQ/Downloads/M11_023/Grafikom%20M10/screenshots/4a_Texture_Nearest.png) | ![Mipmap](file:///c:/Users/Lenovo%20LOQ/Downloads/M11_023/Grafikom%20M10/screenshots/4b_Texture_Mipmap.png) |
| *Gambar 4.4a: Nearest Filtering, tampak aliasing bergerigi dan moiré.* | *Gambar 4.4b: Bilinear Mipmapping, permukaan tergradasi halus anti-alias.* |

* **Analisis Visual:** Pengujian menggunakan tekstur papan catur resolusi tinggi pada bidang lantai miring memperlihatkan perbedaan dramatis. Pada filter Nearest (Gambar 4.4a), texel yang terproyeksi di kejauhan horizon menghasilkan interferensi frekuensi tinggi (*Moiré pattern*) dan pikselasi kasar. Pada filter Bilinear Mipmapping (`GL_LINEAR_MIPMAP_LINEAR`, Gambar 4.4b), tekstur di kejauhan membaur secara halus tanpa distorsi aliasing berkat piramida resolusi mipmap.

---

### 4.5 Pengujian Indikator 5: Real-Time Shadow Mapping, Shadow Acne, dan Peter Panning

| (a) Real-Time Shadow ON (Dynamic Bias + PCF 3×3) | (b) Shadow Mapping OFF (Key 'H') |
|:---:|:---:|
| ![Shadow-ON](file:///c:/Users/Lenovo%20LOQ/Downloads/M11_023/Grafikom%20M10/screenshots/5a_Shadow_ON.png) | ![Shadow-OFF](file:///c:/Users/Lenovo%20LOQ/Downloads/M11_023/Grafikom%20M10/screenshots/5b_Shadow_OFF.png) |
| *Gambar 4.5a: Bayangan realistis dengan dynamic bias & PCF 3x3.* | *Gambar 4.5b: Shadow OFF, objek tampak mengambang tanpa bobot ruang.* |

| (c) Bias = 0 (Shadow Acne Artifact) (Key 'P') | (d) Bias Terlalu Besar (Peter Panning Artifact) (Key 'P') |
|:---:|:---:|
| ![Acne](file:///c:/Users/Lenovo%20LOQ/Downloads/M11_023/Grafikom%20M10/screenshots/5c_Shadow_Acne_Bias0.png) | ![PeterPan](file:///c:/Users/Lenovo%20LOQ/Downloads/M11_023/Grafikom%20M10/screenshots/5d_Shadow_PeterPanning.png) |
| *Gambar 4.5c: Zero Bias, permukaan bola dipenuhi bintik hitam bercak acne.* | *Gambar 4.5d: Large Bias, bayangan terputus/melayang dari pangkal kontak.* |

| (e) Hard Shadow (Tanpa PCF 1×1) (Key 'K') |
|:---:|
| ![PCF-vs-Hard](file:///c:/Users/Lenovo%20LOQ/Downloads/M11_023/Grafikom%20M10/screenshots/5e_Shadow_PCF_vs_Hard.png) |
| *Gambar 4.5e: Single-sample Shadow (1x1), tepi bayangan tampak bergerigi tajam (*staircasing artifact*).* |

* **Analisis Visual:** Gambar 4.5a menunjukkan bayangan jatuh di atas lantai secara realistis dengan tepian lembut (*soft shadow penumbra*) berkat filter PCF 3×3. Pada Gambar 4.5c, peniadaan bias ($\text{bias} = 0$) memperlihatkan fenomena **Shadow Acne**, yaitu bercak hitam kasar pada permukaan bola akibat ketidaktelitian floating-point diskret depth map. Sebaliknya, pada Gambar 4.5d, bias yang berlebihan ($0.06$) memicu **Peter Panning**, di mana bayangan terpisah jauh dari titik tumpu kontak objek. Formula **Dynamic Bias** pada Gambar 4.5a terbukti secara sempurna mengeliminasi kedua artifak tersebut.

---

## BAGIAN 5: PEMBAHASAN & KESIMPULAN

### 5.1 Analisis Komparasi Kinerja Rendering (Tabel Data Benchmark FPS)

Berikut adalah tabel hasil pengukuran kecepatan frame (*Frames Per Second*) secara nyata pada sistem pengujian (resolusi $1280 \times 720$, GPU hardware accelerated, V-Sync OFF):

| Konfigurasi Pengujian | Rata-rata FPS | Analisis Beban Komputasi Arsitektur GPU |
|:---|:---:|:---|
| **Back-Face Culling ON** | **26.384,1 FPS** | **Performa Tertinggi.** GPU membuang 50% segitiga sebelum tahap fragment shader melalui eliminasi cepat winding order CCW. |
| **Shadow Mapping OFF** | **19.913,7 FPS** | Menghindari overhead pembuatan Pass 1 Depth FBO dan peniadaan texture lookup sampler pada Pass 2. |
| **Texture Nearest Neighbor** | **19.757,6 FPS** | Sangat cepat karena texel fetching hanya mengakses 1 alamat memori tekstur per fragment. |
| **Z-Buffer Depth Test OFF** | **19.217,8 FPS** | Mengabaikan read/write depth buffer, namun menghasilkan kehancuran urutan visual objek. |
| **Blinn-Phong Shading Model** | **19.044,0 FPS** | Halfway vector $\mathbf{H}$ dievaluasi sangat efisien di GPU tanpa operasi inversi/pantulan vektor. |
| **Back-Face Culling OFF** | **18.867,3 FPS** | Beban fragment shader bertambah 100% untuk memproses sisi belakang poligon yang sebenarnya tidak terlihat. |
| **Smooth Shading (Per-Vertex Normal)** | **18.279,3 FPS** | Struktur indexed mesh memanfaatkan Post-Transform Vertex Cache GPU secara optimal. |
| **Shadow Bias = 0 (Shadow Acne)** | **17.383,2 FPS** | Shading sederhana tanpa evaluasi PCF 3×3. |
| **Hard Shadow (Single Sample 1×1)** | **16.992,4 FPS** | 1 sampel texture lookup per fragment, jauh lebih cepat daripada kernel PCF 9 sampel. |
| **Flat Shading (Per-Face Normal)** | **16.982,7 FPS** | Throughput verteks meningkat akibat duplikasi data pada struktur non-indexed array. |
| **Z-Buffer Depth Test ON** | **14.657,0 FPS** | Operasi perbandingan dan pembaruan depth buffer per-pixel (standar wajib grafika 3D). |
| **Real-Time Shadow (Dynamic + PCF 3×3)**| **11.220,0 FPS** | Dua-pass rendering + 9 kali texture lookup per fragment untuk penyaringan penumbra halus. |
| **Shadow Bias Besar (Peter Panning)** | **10.146,8 FPS** | Evaluasi bias statis pada fragment shader. |
| **Texture Bilinear + Mipmapping** | **9.332,9 FPS** | Trilinear filtering melakukan 8 kali pembacaan texel dan interpolasi antar 2 level piramida mipmap. |
| **Phong Shading Model** | **4.825,4 FPS** | Operasi perhitungan vektor refleksi $\mathbf{R} = 2(\mathbf{N}\cdot\mathbf{L})\mathbf{N}-\mathbf{L}$ dan perpangkatan per-fragment membebani ALU GPU secara signifikan. |

---

### 5.2 Analisis Fenomena Shadow Bias: Komparasi Shadow Acne dan Peter Panning

Eksperimen membuktikan bahwa pemilihan bias kedalaman pada shadow mapping merupakan kompromi kritis (*trade-off*):
1. **Penyebab Shadow Acne ($\text{bias} = 0$):** Depth map memiliki resolusi diskret (grid texel). Saat suatu fragmen permukaan bola miring dipetakan ke dalam koordinat depth map, titik tengah texel depth map merekam kedalaman yang sedikit berbeda dari posisi permukaan analitis fragmen tersebut. Akibatnya, separuh fragmen menganggap dirinya sendiri berada di belakang depth map (*self-shadowing*), memunculkan pola moiré gelap belang-belang menyerupai jerawat (*acne*).
2. **Penyebab Peter Panning ($\text{bias} = 0.06$):** Untuk menghilangkan acne, penambahan bias statis konstan yang terlalu besar menggeser bidang pembanding kedalaman terlalu jauh ke dalam objek. Akibatnya, area kontak di mana bola menyentuh lantai kehilangan bayangan, dan bayangan baru mulai terbentuk beberapa sentimeter di belakang objek, memberikan ilusi visual bahwa bola melayang di udara (*Peter Pan effect*).
3. **Efektivitas Dynamic Slope-Scale Bias:** Formula yang diterapkan pada shader:
   $$\text{bias} = \max\Big(0.05 \cdot (1.0 - \mathbf{N} \cdot \mathbf{L}), \, 0.005\Big)$$
   secara cerdas memberikan bias kecil ($0.005$) pada permukaan yang tegak lurus cahaya ($\mathbf{N} \cdot \mathbf{L} \approx 1$), sehingga pangkal bayangan tetap menempel kuat pada lantai (mencegah Peter Panning), dan secara otomatis menaikkan bias hingga $0.05$ pada permukaan yang miring terhadap cahaya ($\mathbf{N} \cdot \mathbf{L} \to 0$), sehingga seluruh bayangan palsu self-shadowing acne berhasil dieliminasi secara tuntas.

---

### 5.3 Analisis Perbedaan Mendasar Gouraud Shading vs Phong Shading

Terdapat perbedaan mendasar dalam pipeline interpolasi pencahayaan grafika komputer:
1. **Gouraud Shading (Per-Vertex Lighting):**
   * Persamaan model pencahayaan Phong/Blinn-Phong dieksekusi di dalam **Vertex Shader** hanya pada titik-titik verteks.
   * Nilai warna ($RGB$) hasil perhitungan kemudian diinterpolasikan secara linier melintasi segitiga menuju fragment shader.
   * *Kelemahan:* Sangat cepat, namun gagal merepresentasikan specular highlight berukuran kecil yang jatuh di tengah-tengah poligon face tanpa mengenai verteks. Selain itu, kilauan tampak mengalami distorsi bentuk segitiga poligonal.
2. **Phong Shading (Per-Pixel Lighting) — Yang Diimplementasikan pada Suite Ini:**
   * Vertex shader hanya bertugas meneruskan dan menginterpolasikan **Vektor Normal Vertex** $\mathbf{N}$ dan posisi fragmen $\mathbf{P}$.
   * Persamaan lengkap pencahayaan ambient, diffuse, dan specular Blinn-Phong dieksekusi secara independen pada tingkat **Fragment Shader** untuk setiap pixel individu.
   * *Keunggulan:* Specular highlight tampil bulat sempurna, presisi tinggi, dan kilauan bergerak mulus melintasi permukaan objek tanpa dipengaruhi kerapatan mesh poligon.

---

### 5.4 Kesimpulan Kontribusi Pilar Visual Realism

Berdasarkan keseluruhan hasil perancangan, implementasi, dan pengujian pada tugas Minggu ke-11 ini, dapat diambil kesimpulan komprehensif:
1. **Model Pencahayaan (Blinn-Phong):** Memberikan realisme material fisik objek melalui simulasi specular highlight yang stabil dan efisien di GPU, melampaui performa model Phong standar hingga hampir 4 kali lipat.
2. **Interpolasi Permukaan (Smooth Shading):** Menghilangkan diskontinuitas visual dan ilusi Mach Banding pada mesh beresolusi rendah melalui teknik averaging normal vertex yang diinterpolasi per-pixel.
3. **Hidden Surface Removal (Z-Buffer & Culling):** Z-Buffer adalah komponen mutlak untuk menjaga koherensi oklusi spasial 3D, sementara Back-Face Culling terbukti sebagai optimasi paling efektif yang meningkatkan throughput rendering hingga $26.384$ FPS.
4. **Pemetaan Tekstur (Mipmapping):** Mencegah aliasing frekuensi tinggi dan distorsi pola Moiré pada permukaan lantai miring yang membentang ke horizon, memberikan ketajaman visual yang bersih dan stabil.
5. **Bayangan Real-Time (Shadow Mapping 2-Pass):** Memberikan persepsi kedalaman ruang (*spatial cues*) dan kontak fisik objek terhadap lingkungannya. Integrasi Dynamic Slope-Scale Bias dan Percentage-Closer Filtering (PCF 3×3) terbukti sukses menghasilkan bayangan berpenumbra lembut bebas dari cacat Shadow Acne maupun Peter Panning.

Kombinasi kelima teknik ini berhasil menyatukan aplikasi sederhana Minggu ke-10 menjadi **3D Visual Realism Suite** yang tangguh, modular, interaktif, dan memenuhi standar tertinggi rubrik penilaian Grafika Komputer modern.
