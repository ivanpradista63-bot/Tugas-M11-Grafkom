@echo off
setlocal
echo ========================================================
echo   MENJALANKAN 3D VISUAL REALISM SUITE (MINGGU 11)
echo ========================================================

set "JAVA_BIN=C:\Program Files\Java\jdk-25\bin\java.exe"
if not exist "%JAVA_BIN%" set "JAVA_BIN=java"

set "CP=target\classes;%USERPROFILE%\.m2\repository\org\lwjgl\lwjgl\3.3.3\lwjgl-3.3.3.jar;%USERPROFILE%\.m2\repository\org\lwjgl\lwjgl\3.3.3\lwjgl-3.3.3-natives-windows.jar;%USERPROFILE%\.m2\repository\org\lwjgl\lwjgl-glfw\3.3.3\lwjgl-glfw-3.3.3.jar;%USERPROFILE%\.m2\repository\org\lwjgl\lwjgl-glfw\3.3.3\lwjgl-glfw-3.3.3-natives-windows.jar;%USERPROFILE%\.m2\repository\org\lwjgl\lwjgl-opengl\3.3.3\lwjgl-opengl-3.3.3.jar;%USERPROFILE%\.m2\repository\org\lwjgl\lwjgl-opengl\3.3.3\lwjgl-opengl-3.3.3-natives-windows.jar;%USERPROFILE%\.m2\repository\org\lwjgl\lwjgl-stb\3.3.3\lwjgl-stb-3.3.3.jar;%USERPROFILE%\.m2\repository\org\lwjgl\lwjgl-stb\3.3.3\lwjgl-stb-3.3.3-natives-windows.jar;%USERPROFILE%\.m2\repository\org\joml\joml\1.10.5\joml-1.10.5.jar"

"%JAVA_BIN%" -cp "%CP%" "-Dorg.lwjgl.util.Debug=false" com.grafkom.viewing3d.Main

endlocal
