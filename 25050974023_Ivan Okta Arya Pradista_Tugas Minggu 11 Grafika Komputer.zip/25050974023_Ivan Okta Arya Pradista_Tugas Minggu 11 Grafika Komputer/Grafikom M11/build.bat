@echo off
setlocal
echo ========================================================
echo   BUILDING 3D VISUAL REALISM SUITE (MINGGU 11)
echo ========================================================

set "JAVAC_BIN=C:\Program Files\Java\jdk-25\bin\javac.exe"
if not exist "%JAVAC_BIN%" set "JAVAC_BIN=javac"

set "CP=%USERPROFILE%\.m2\repository\org\lwjgl\lwjgl\3.3.3\lwjgl-3.3.3.jar;%USERPROFILE%\.m2\repository\org\lwjgl\lwjgl-glfw\3.3.3\lwjgl-glfw-3.3.3.jar;%USERPROFILE%\.m2\repository\org\lwjgl\lwjgl-opengl\3.3.3\lwjgl-opengl-3.3.3.jar;%USERPROFILE%\.m2\repository\org\lwjgl\lwjgl-stb\3.3.3\lwjgl-stb-3.3.3.jar;%USERPROFILE%\.m2\repository\org\joml\joml\1.10.5\joml-1.10.5.jar"

if not exist "target\classes" mkdir "target\classes"

echo Mengompilasi kode sumber Java...
"%JAVAC_BIN%" -d "target\classes" -cp "%CP%" src\main\java\com\grafkom\viewing3d\*.java

if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Kompilasi gagal!
    pause
    exit /b %ERRORLEVEL%
)

echo Menyalin resources (shaders & textures)...
xcopy /E /I /Y "src\main\resources\*" "target\classes\" >nul

echo ========================================================
echo   KOMPILASI SELESAI DENGAN SUKSES!
echo ========================================================
endlocal
